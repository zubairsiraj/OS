# Image References :

The images in the documentation are taken from the [Introduction to Operating Systems](https://www.udacity.com/course/introduction-to-operating-systems--ud923) course at Udacity as screenshots so as to improve the notes and also provide visual aid to understand the concepts quickly and effectively.


<hr>